<?php
    //variable system
    echo "dokumen root " .$_SERVER["DOCUMENT_ROOT"];
    echo "<br/>nama file " .$_SERVER["PHP_SELF"];
?>