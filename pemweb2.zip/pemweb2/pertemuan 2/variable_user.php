<?php
    //mendefinisikan variables
    $nama = "Bimo";
    $umur = 21;
    $bb = 67;

    echo "nama saya adallah : " .$nama;
    echo "<br/>umur : " .$umur. "tahun" ;
    echo "<br/>berat badan : " .$bb. "kg";
?>