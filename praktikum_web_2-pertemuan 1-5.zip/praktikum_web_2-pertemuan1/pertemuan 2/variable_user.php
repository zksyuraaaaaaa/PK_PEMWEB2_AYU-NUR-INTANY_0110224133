<?php
    //mendefinisikan variables
    $nama = "Arsya";
    $umur = 20;
    $bb = 78;

    echo "nama saya adallah : " .$nama;
    echo "<br/>umur : " .$umur. "tahun" ;
    echo "<br/>berat badan : " .$bb. "kg";
?>